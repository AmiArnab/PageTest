Instructions:
1) Extract archive
2) Disable your antiviris (Windows defender should be disabled while you run this tool)
3) Run Re-Loader Activator and select which product you want to activate
DONE!
 

www.Techtools.net /  www.ThumperDC.com